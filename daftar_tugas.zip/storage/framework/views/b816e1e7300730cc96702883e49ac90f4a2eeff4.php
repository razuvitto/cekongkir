<?php $__env->startSection('judul'); ?>
Daftar Tugas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<table class="table table-hover">
	<thread>
		<tr>
			<th>Judul</th>
			<th>Detail</th>
			<th>Edit</th>
			<th>Hapus</th>
		</tr>
	</thread>
	<tbody>
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($a->judul); ?></td>
				<td>
					<a href="<?php echo e(url('tugas/'.$a->id)); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-eye-open"></i></a>
				</td>
				<td>
					<a href="<?php echo e(url('tugas/'.$a->id. '/edit')); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-edit"></i></a>
				</td>
				<td>
					<form action="<?php echo e(url('tugas/'.$a->id)); ?>" method="post">
						<?php echo e(csrf_field()); ?>

						<input type="hidden" name="_method" value="DELETE">
						<button type="submit" class="btn btn-danger"><i class="glyphicon glyphicon-trash"></i></button>	
					</form>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>