<?php $__env->startSection('judul'); ?>
Detail Tugas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<table class="table table-hover">
	<thread>
		<tr>
			<th>Judul</th>
			<th>Deskripsi</th>
			<th>Dibuat Pada</th>
		<tr>
	</thread>
	<tbody>
		<tr>
			<td><?php echo e($data->judul); ?></td>
			<td><?php echo e($data->deskripsi); ?></td>
			<td><?php echo e($data->created_at); ?></td>
		</tr>
	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>