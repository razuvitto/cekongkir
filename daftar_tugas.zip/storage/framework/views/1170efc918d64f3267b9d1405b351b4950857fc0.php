<?php $__env->startSection('judul'); ?>
Edit Tugas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<form action="<?php echo e(url('tugas/'.$data->id)); ?>" method="post">
	<input type="hidden" name="_method" value="PUT">
	<?php echo e(csrf_field()); ?>

	<label>Judul</label>
	<input type="text" name="judul" value="<?php echo e($data->judul); ?>" class="form-control">
	<label>Deskripsi</label>
	<input type="text" name="deskripsi" value="<?php echo e($data->deskripsi); ?>" class="form-control">
	<input type="submit" class="btn btn-success" value="Simpan">
</form>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>