<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('judul'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
</head>
<body>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <a href="<?php echo e(url('/tugas/create')); ?>" class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Tambah</a>
            <a href="<?php echo e(url('/tugas')); ?>" class="btn btn-primary"><i class="glyphicon glyphicon-list"></i> Daftar Tugas</a>
        <div>
    </div>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <?php echo $__env->yieldContent('konten'); ?>
        <div>
    </div>
</body>
</html>